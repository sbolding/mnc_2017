ANS Transactions LaTeX template
===============================


Compiling
----------------

    pdflatex example
    bibtex example
    pdflatex example
    pdflatex example
